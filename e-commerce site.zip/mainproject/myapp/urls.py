from django.contrib import admin
from django.urls import path,include
from myapp import views

urlpatterns = [

#index:
    path('',views.index),
    path('home',views.home),
#User:
    path('register',views.register),
    path('former_data',views.regform),
    path('login_page',views.login_page),
    path('user_layout',views.check),
    path('log_form',views.demo),
    path("user_logout",views.user_logout),
#Farmer:
    path('farmer_log',views.farmerlog),
    path('farm_reg',views.farmreg),
    path('reg_farm',views.farmer_register),
    path('farm_log',views.demo1),
    path('farmer_lay',views.check1),
# path('farmer_out',views.farm_out),
    path('fadd',views.fadd),
    path('addfarm',views.addfamer),
    path('farview',views.farmview),
    path('delete/<int:id>',views.fardel),
    path('update/<int:id>',views.update),
    path('update_data',views.updfarm),
    path("farmer_logout",views.farmer_logout),
    path('farorder',views.farmerordstatus),
    path('constatus',views.updastatus),

#Admin path:
    path('adlog1',views.adlog),
    path('admin',views.admin1),
    path('adminlay',views.adminlay),
    path('viewfarmer',views.adfarview),
    path('viewfarmer/<int:id>',views.status1),
    path('userview1',views.userview),
    path('userview1/<int:id>',views.status2),
    path('admin_logout',views.admin_logout),
    path('avorder',views.avorder),

#User Add & Buy cart:
    path('plus_cart/<int:id>',views.addcart1),
    path('viewaddcart',views.viewaddcart),
    path('buycar/<int:id>',views.buycart1),
    path('payment/<int:id>',views.pay),
    path('payfinish/<int:id>',views.payfinish),
    path('orderview',views.orderview),
    path('orderview/<int:id>',views.orderview),


    path('sample',views.sample),

    
    


   
]