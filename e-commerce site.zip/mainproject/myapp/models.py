from django.db import models

# Create your models here.
class user(models.Model):
    Email=models.CharField(max_length=100)
    Mobile_Number=models.CharField(max_length=100)
    Password=models.CharField(max_length=100)
    status=models.BooleanField(default=0)
    def __str__(self):
        return self.Email
    
class farmer(models.Model):
    Email=models.CharField(max_length=100)
    Mobile_Number=models.CharField(max_length=100)
    Password=models.CharField(max_length=100)
    status=models.BooleanField(default=0)
    def __str__(self):
        return self.Email
    
class addfarm(models.Model):
    Product_Name=models.CharField(max_length=100)
    Product_Code=models.CharField(max_length=100)
    Quantity=models.CharField(max_length=100)
    Rate=models.CharField(max_length=100)
    Images=models.FileField(max_length=100,upload_to='image',null=True,blank=True)
    Farmer_Name=models.CharField(max_length=100,null=True)
    

class addcart(models.Model):
    Product_Name=models.CharField(max_length=100)
    Product_Code=models.CharField(max_length=100)
    Quantity=models.CharField(max_length=100)
    Rate=models.CharField(max_length=100)
    Images=models.FileField(max_length=100,upload_to='image',null=True,blank=True)
    Farmer_Name=models.CharField(max_length=100)
    User_name=models.CharField(max_length=100)
    def __str__(self):
        return self.Product_Name
    
class buycart(models.Model):
    Product_Name=models.CharField(max_length=100)
    Product_Code=models.CharField(max_length=100)
    Quantity=models.CharField(max_length=100)
    Rate=models.CharField(max_length=100)
    Images=models.FileField(max_length=100,upload_to='image',null=True,blank=True)
    Farmer_Name=models.CharField(max_length=100)
    User_name=models.CharField(max_length=100)
    Status=models.CharField(max_length=100,default="pending")
    def __str__(self):
        return self.Product_Name


    




