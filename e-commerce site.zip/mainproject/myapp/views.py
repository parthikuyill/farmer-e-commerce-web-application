from django.shortcuts import render
from myapp.models import *
from django.http import HttpResponseRedirect

# Create your views here.

def login_page(request):
    return render(request,"user/login_page.html")

def register(request):
    return render(request,"user/register.html")

def index(request):
    return render(request,"index.html")

def home(request):
    return render(request,"home.html")


#user regform:
def regform(request):
    if request.method == 'POST':
        email=request.POST['email']
        mobilenumber=request.POST['Mobile Number']
        password=request.POST['Password']
        

        former=user()
        former.Email=email
        former.Mobile_Number=mobilenumber
        former.Password=password
        former.save()
        return render(request,"user/login_page.html",{'Email':email,'Mobile_Number':mobilenumber,'Password':password})
    
def demo(request):
    if request.method == 'POST':
        email=request.POST['email']
        password=request.POST['password']
        if user.objects.filter(Email=email,Password=password).exists():
            request.session['user']=email
            return HttpResponseRedirect('/user_layout')
        else:
            return HttpResponseRedirect('login_page')
        

def check(request):
    if request.session.has_key('user'):
        store=addfarm.objects.all()
        return render(request,"user/user_layout.html",{"store3":store})
    else:
        return HttpResponseRedirect('/login_page')
    
def farmerlog(request):
    return render(request,"farmer/farmer_log.html")

def farmreg(request):
    return render(request,"farmer/farm_reg.html")

def falay(request):
    if request.session.has_key('farm'):
        return render(request,"farmer/farmer_lay.html")
    else:
        return HttpResponseRedirect('/farmer_log')

def farmer_register(request):
    if request.method == 'POST':
        email=request.POST['email']
        mobilenumber=request.POST['Mobile Number']
        password=request.POST['Password']
        

        former=farmer()
        former.Email=email
        former.Mobile_Number=mobilenumber
        former.Password=password
        former.save()
        return render(request,"farmer/farmer_log.html",{'Email':email,'Mobile_Number':mobilenumber,'Password':password})

#session:    
def demo1(request):
    if request.method == 'POST':
        email=request.POST['email']
        password=request.POST['password']
        if farmer.objects.filter(Email=email,Password=password).exists():
            request.session['farm']=email
            return HttpResponseRedirect('/farmer_lay')
        else:
            return HttpResponseRedirect('/farmer_log')
        
def check1(request):
    if request.session.has_key('farm'):
        return render(request,"farmer/farmer_lay.html")
    else:
        return HttpResponseRedirect("farmer_log")

def fadd(request):
    if request.session.has_key('farm'):
        return render(request,"farmer/farmap.html")
    else:
        return HttpResponseRedirect('/')

#add:
def addfamer(request):
    
    if request.method == 'POST':
        proname=request.POST['pname']
        procode=request.POST['pcode']
        proqty=request.POST['qt']
        prorate=request.POST['rate']
        prfile=request.FILES['imgfile']
        res=request.session['farm']

        ap=addfarm()
        ap.Product_Name=proname
        ap.Product_Code=procode
        ap.Quantity=proqty
        ap.Rate=prorate
        ap.Images=prfile
        ap.Farmer_Name=res
        ap.save()
        return HttpResponseRedirect('/fadd')
    
#view:    
def farmview(request):
    if request.session.has_key('farm'):
        email=request.session['farm']
        store=addfarm.objects.filter(Farmer_Name=email)
        return render(request,"farmer/farview.html",{"store":store})
    else:
        return HttpResponseRedirect('/')

#delete:
def fardel(request,id):
    if request.session.has_key('farm'):
        store=addfarm.objects.get(id=id)
        store.delete()
        return HttpResponseRedirect("/farview")
    else:
        HttpResponseRedirect('/')

#update:
def update(request,id):
    if request.session.has_key('farm'):
        store=addfarm.objects.get(id=id)
        return render(request,"farmer/update.html",{"up":store})
    else:
        return HttpResponseRedirect('/')

def updfarm(request):
    if request.session.has_key('farm'):
        if request.method == 'POST':
            id=int(request.POST['idd'])
            proname=request.POST['pname']
            procode=request.POST['pcode']
            proqty=request.POST['qt']
            prorate=request.POST['rate']
            prfile=request.FILES['imgfile']

            ap1=addfarm.objects.get(id=id)
            ap1.Product_Name=proname
            ap1.Product_Code=procode
            ap1.Quantity=proqty
            ap1.Rate=prorate
            ap1.Images=prfile
            ap1.save()
            return HttpResponseRedirect('/farview')
    else:
        return HttpResponseRedirect('/')

#admin Login:
def adlog(request):
    return render(request,'admin/adlog.html')

#admin_layout URL:
def adminlay(request):
    if request.session.has_key('admin'):
        return render(request,'admin/adlay.html')
    else:
        return HttpResponseRedirect('adlog1')

#admin/view farmer page URL:
def viewfarmer(request):
    if request.session.has_key('admin'):
        return render(request,"admin/view_farm.html")
    else:
        return HttpResponseRedirect('adlog1')

#view farmer:
def adfarview(request):
    if request.session.has_key('admin'):
        store=farmer.objects.all()
        return render(request,"admin/view_farm.html",{"store1":store})
    else:
        return HttpResponseRedirect('adlog1')

def status1(request,id):
    store=farmer.objects.get(id=id)
    if store.status == 0:
        store.status=1
        store.save()
    else:
        store.status=0
        store.save()
    return HttpResponseRedirect('/viewfarmer')

#view user:
def userview(request):
    if request.session.has_key('admin'):
        store3=user.objects.all()
        return render(request,"admin/viuser.html",{"store2":store3})
    else:
        return HttpResponseRedirect('adlog1')

def status2(request,id):
    store=user.objects.get(id=id)
    if store.status == 0:
        store.status=1
        store.save()
    else:
        store.status=0
        store.save()
    return HttpResponseRedirect('/userview1')

def admin1(request):
    if request.method == 'POST':
        un=request.POST["email"]
        ps=request.POST["password"]
        if un=="admin" and ps=="admin":
            request.session["admin"] = un
            return HttpResponseRedirect('/adminlay')
        else:
            return HttpResponseRedirect('/adlog1')
        
def admin_logout(request):
    if request.session.has_key('admin'):
        del request.session['admin']
        return HttpResponseRedirect('/adlog1')
    else:
        return HttpResponseRedirect('/adlog1')
        

def farmer_logout(request):
    if request.session.has_key('farm'):
        del request.session['farm']
        return HttpResponseRedirect('/farmer_log')
    else:
        return HttpResponseRedirect('/farmer_log')
    
def user_logout(request):
    if request.session.has_key('user'):
        del request.session['user']
        return HttpResponseRedirect('login_page')
    else:
        return HttpResponseRedirect('login_page')

def addcart1(request,id):
    if request.session.has_key('user'):
        res=addfarm.objects.get(id=id)
        res8=request.session['user']
        cart1=addcart()
        cart1.Product_Name=res.Product_Name
        cart1.Product_Code=res.Product_Code
        cart1.Quantity=res.Quantity
        cart1.Rate=res.Rate
        cart1.Images=res.Images
        cart1.Farmer_Name=res.Farmer_Name
        cart1.User_name=res8
        cart1.save()
        
        return HttpResponseRedirect('/user_layout')
    else:
        return HttpResponseRedirect('/user_layout')
def viewaddcart(request):
    if request.session.has_key('user'):
        email=request.session['user']
        cart1=addcart.objects.filter(User_name=email)
        return render(request,"user/addcart.html",{'cart5':cart1})
    else:
        return HttpResponseRedirect('user_layout')
    


def buycart1(request,id):
    if request.session.has_key('user'):
        res=addfarm.objects.get(id=id)
        return render(request,"user/buycart.html",{"res":res})
    else:
        return HttpResponseRedirect('login_page')  
    
def pay(request,id):
    if request.session.has_key('user'):
        res=id
        return render(request,"user/payment.html",{'res':res})
    else:
        return HttpResponseRedirect('login_page')
    
def payfinish(request,id):
    if request.session.has_key('user'):
        res=addfarm.objects.get(id=id)
        buy1=request.session['user']
        buy=buycart()
        buy.Product_Name=res.Product_Name
        buy.Product_Code=res.Product_Code
        buy.Quantity=res.Quantity
        buy.Rate=res.Rate
        buy.Images=res.Images
        buy.Farmer_Name=res.Farmer_Name
        buy.User_name=buy1
        buy.save()
        return HttpResponseRedirect('/user_layout')
    else:
        return HttpResponseRedirect('/login_page')
    

    
def orderview(request):
    if request.session.has_key('user'):
        email=request.session['user']
        cart4=buycart.objects.filter(User_name=email)
        return render(request,"user/vieworder.html",{'viewcart':cart4})
    else:
        return HttpResponseRedirect('/user_layout')
    
    
def orderstatus(request,id):
    orderstore=buycart.objects.get(id=id)
    if orderstore.status == 0:
        orderstore.status=1
        orderstore.save()
    else:
        orderstore.status=0
        orderstore.save()
    return HttpResponseRedirect('/orderview')

def avorder(request):
    if request.session.has_key('admin'):
        aov=buycart.objects.all()
        return render(request,"admin/advieworder.html",{"vieworder":aov})
    else:
        return HttpResponseRedirect('adlog1')

#orderstatus farmer:
def farmerordstatus(request):
    if request.session.has_key('farm'):
        email=request.session['farm']
        order1=buycart.objects.filter(Farmer_Name=email)
        return render(request,"farmer/orderstatus.html",{'farmorder':order1})
    else:
        return HttpResponseRedirect('/farmer_log')
    
def updastatus(request):
    if request.session.has_key('farm'):
        if request.method == 'POST':
            id=int(request.POST['id8'])
            red=request.POST['boss']

            stat=buycart.objects.get(id=id)
            stat.Status=red
            stat.save()
            return HttpResponseRedirect('farorder')
        else:
            return HttpResponseRedirect('farmer_log')
    else:
        return HttpResponseRedirect('farmer_log')

def sample(request):
    return render(request,"sample.html")





    








    









    




    
        




